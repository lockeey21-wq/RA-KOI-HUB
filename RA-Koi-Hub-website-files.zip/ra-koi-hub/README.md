# R&A Koi Hub

A free static website for koi-keeping information.

## Files
- `index.html` – main website
- `style.css` – design and responsive layout
- `script.js` – pond water-volume calculator

## Publish on GitHub Pages
1. Create a GitHub repository.
2. Upload these three files to the repository's main branch.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)`.
6. Save. GitHub will provide the website address once it finishes publishing.
