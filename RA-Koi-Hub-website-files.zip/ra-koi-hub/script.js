function calculate(){
  const l=parseFloat(document.getElementById("length").value);
  const w=parseFloat(document.getElementById("width").value);
  const d=parseFloat(document.getElementById("depth").value);
  const out=document.getElementById("result");
  if(!(l>0&&w>0&&d>0)){out.textContent="Please enter a valid length, width and average depth.";return;}
  const m3=l*w*d, litres=m3*1000, gallons=litres*0.219969;
  out.innerHTML=`Estimated volume: <strong>${litres.toLocaleString(undefined,{maximumFractionDigits:0})} litres</strong> (${m3.toFixed(2)} m³ / ${gallons.toFixed(0)} UK gallons).`;
}
